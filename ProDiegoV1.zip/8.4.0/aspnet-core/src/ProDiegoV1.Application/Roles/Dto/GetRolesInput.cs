﻿namespace ProDiegoV1.Roles.Dto
{
    public class GetRolesInput
    {
        public string Permission { get; set; }
    }
}
